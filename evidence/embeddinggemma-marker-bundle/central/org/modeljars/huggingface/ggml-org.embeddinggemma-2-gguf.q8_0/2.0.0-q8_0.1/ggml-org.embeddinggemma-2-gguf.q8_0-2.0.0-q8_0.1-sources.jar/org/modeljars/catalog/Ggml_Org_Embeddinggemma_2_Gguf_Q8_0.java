package org.modeljars.catalog;

import org.modeljars.ModelJar;

/** Type-safe reference carried by the ggml_org_embeddinggemma_2_gguf_q8_0 marker JAR. */
public final class Ggml_Org_Embeddinggemma_2_Gguf_Q8_0 {
  /** Exact marker coordinate for this model artifact. */
  public static final ModelJar MODEL =
      ModelJar.of("org.modeljars.huggingface:ggml-org.embeddinggemma-2-gguf.q8_0:2.0.0-q8_0.1");

  private Ggml_Org_Embeddinggemma_2_Gguf_Q8_0() {}
}
